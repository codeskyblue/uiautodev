#!/usr/bin/env python3
# coding=utf-8

#
# Copyright (c) 2022 Huawei Device Co., Ltd.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import os
import re
import time
import traceback
import hashlib

from xdevice import DeviceConnectorType
from xdevice import TestDeviceState
from xdevice import check_uitest_version
from xdevice import AgentMode

from devicetest import RESOURCE_PATH
from devicetest.core.variables import DeccVariable
from devicetest.log.logger import DeviceTestLog as log
from devicetest.controllers.tools.screen_agent import ScreenAgent
from devicetest.utils.util import get_process_pid
from devicetest.utils.util import get_forward_port
from devicetest.utils.util import check_device_file_md5
from devicetest.controllers.tools.recorder.rpc_manager import RpcManager

MIN_FRAME_COUNT = 10


class RecordAgent:
    instance = {}

    def __new__(cls, device):
        """
        Singleton instance
        """
        if device.device_sn not in cls.instance:
            # 创建新的实例并存储
            cls.instance[device.device_sn] = super(RecordAgent, cls).__new__(cls)
        return cls.instance[device.device_sn]

    def __init__(self, device):
        if not hasattr(self, '_device'):
            self._device = device
            self.log = device.log
            self.scrcpy_server_port = 5001
            self.scrcpy_port = None
            self.running_status = None
            self.server = None

    def __del__(self):
        self.terminate()

    def _init_rpc_server(self):
        self.log.debug("Init rpc server.")
        self.server = RpcManager(self._device, self._device.host, self.scrcpy_port)

    def start_and_check_rpc_server(self):
        if self.running_status is None:
            self.running_status = self._start_scrcpy_serevr()
            self._init_rpc_server()
        return self.running_status

    @classmethod
    def _compare_software_version(cls, version, base_version: tuple, rex: str):
        """比较两个版本号的大小,若version版本大于等于base_version,返回True
        Args:
            version: str, version
            rex: version style rex
            base_version: list, base_version
        Example:
            version: "ALN-AL00 5.0.0.22(SP33DEVC00E22R4P1log)" base_version:[5.0.0.22]
            if version bigger than base_version or equal to base_version, return True, else return False
        """
        result = re.findall(rex, version)
        if result:
            version = tuple(result[0].split("."))
            if version > base_version:
                return True
        else:
            return True
        return False

    def _get_scrcpy_uitest_process(self) -> str:
        result = self._device.execute_shell_command('\"ps -ef | grep singleness\"')
        proc_running = result.split("\n")
        for data in proc_running:
            if ("singleness" in data and "grep" not in data
                    and "extension-name" in data and "libscreen_recorder" in data):
                data = data.split()
                return data[1]
        return None

    def _push_scrcpy_server(self, server_name):
        # 判断是否存在或是否更新
        pc_path = os.path.join(RESOURCE_PATH, "res", "recorder", server_name)
        device_path = "/data/local/tmp/libscreen_recorder.z.so"
        if not check_device_file_md5(self._device, pc_path, device_path):
            # kill old process
            pid = self._get_scrcpy_uitest_process()
            if pid:
                self._device.execute_shell_command('\"kill -9 {}\"'.format(pid))
            self.log.debug("start update {}".format(device_path))
            self._device.execute_shell_command("mount -o rw,remount /")
            self._device.connector_command("target mount")
            self._device.execute_shell_command(f'\"rm -f {device_path}\"')
            self._device.push_file(pc_path, device_path)
            self.log.debug("Finish update server.")
        else:
            self.log.debug("Record server does not need to update.")

    def _start_scrcpy_serevr(self):
        is_using_new_so = False
        uitest_version = self._device.execute_shell_command("/system/bin/uitest --version")
        base_version = tuple("4.1.4.6".split("."))
        if not check_uitest_version(uitest_version, base_version):
            self.log.error("Finish update server.")
            return False
        software_base_version = tuple("5.0.0.25".split("."))
        if self._check_software_version(software_base_version):
            is_using_new_so = True
        # 先检测是否需要更新sevrer
        if not is_using_new_so:
            self.log.debug("Using old scrcpy so.")
            self._push_scrcpy_server(server_name="libscrcpy_server_old.z.so")
        else:
            self.log.debug("Using new scrcpy so.")
            self._push_scrcpy_server(server_name="libscrcpy_server.z.so")

        # 2、设置转发端口
        self.scrcpy_port = get_forward_port(self._device, self._device.host)
        self._device.connector_command("fport tcp:{} tcp:{}".format(self.scrcpy_port, self.scrcpy_server_port))
        # 3、判断scrcpy是否已经启动
        pid = self._get_scrcpy_uitest_process()
        if pid:
            self.log.debug("record server is running. pid is {}".format(pid))
            return True
        # 4、启动scrcpy -m 1表示仅启动录屏模式
        self._device.execute_shell_command("/system/bin/uitest start-daemon singleness "
                                           "--extension-name libscreen_recorder.z.so -p {} -m 1"
                                           .format(self.scrcpy_server_port))
        # 检测scrcpy是否正常启动
        pid = self._get_scrcpy_uitest_process()
        if pid is None:
            self.log.error("Start record server failed.")
            return False
        self.log.debug("Record server pid: {}".format(pid))
        time.sleep(1)
        return True

    def _check_software_version(self, base_version):
        software_version = self._device.execute_shell_command("param get const.product.software.version")
        self.log.debug("software version is {}".format(software_version))
        if (software_version and
                self._compare_software_version(software_version, base_version, r'\b\d{1,3}.\d{1,3}.\d{1,3}.\d{1,3}\b')):
            return True
        openharmony_version = self._device.execute_shell_command("param get const.ohos.fullname")
        self.log.debug("openharmony version is {}".format(openharmony_version))
        if (openharmony_version and
                self._compare_software_version(openharmony_version, base_version,
                                               r'\b\d{1,3}.\d{1,3}.\d{1,3}.\d{1,3}\b')):
            return True
        return False

    @classmethod
    def get_device(cls, args):
        if len(args) == 0:
            return None
        _device = args[0]
        try:
            if not hasattr(_device, "screenrecorder"):
                _device = None
                # 适配Hypium的AW接口
                for arg in args:
                    _device = getattr(arg, "_device", None)
                    if _device is not None:
                        break
                if _device is None:
                    log.info("check device object failed.")
                    return None
        except ImportError:
            log.warning("failed in start_screen_recorder function.")
        return _device

    @classmethod
    def start_screen_recorder(cls, args):
        try:
            _device = cls.get_device(args)
            if _device is None:
                return
            if not hasattr(_device, "_agent_mode") or getattr(_device, "_agent_mode") != AgentMode.bin:
                return
            if not hasattr(_device, "screenrecorder") or _device.screenrecorder is False:
                return
            # 设备处于断开状态，不执行录屏
            if hasattr(_device, 'test_device_state') and _device.test_device_state != TestDeviceState.ONLINE:
                _device.log.warning("device state is not online")
                return
            agent = RecordAgent(_device)
            agent.start_and_check_rpc_server()
            # 已经开始录制就不在执行下面
            if hasattr(_device, "recorder_start_time") and getattr(_device, "recorder_start_time") is not None:
                return
            if hasattr(_device, "is_oh") and agent.start_and_check_rpc_server():
                agent.server.start_scrcpy()
                setattr(_device, "recorder_start_time", time.time())
            else:
                return
        except Exception as e:
            log.error(f"start screen recorder error, {e}")
            log.debug(traceback.format_exc())

    @classmethod
    def stop_screen_recorder(cls, file_name, file_desc, args, index: int):
        """stop recording screen
        file_name: str, 录屏视频文件名
        file_desc: str，录屏视频文件描述
        args: list, the list of devices
        """
        file_name = file_name or "stepepr"
        try:
            _device = cls.get_device(args)
            if _device is None:
                return

            if not hasattr(_device, "screenrecorder") or _device.screenrecorder is False:
                return
            # 设备处于断开状态，不执行录屏
            if hasattr(_device, 'test_device_state') and _device.test_device_state != TestDeviceState.ONLINE:
                _device.log.warning("device state is not online")
                return
            agent = RecordAgent(_device)
            cur_case = DeccVariable.cur_case()
            # 非bin模式就只做截图
            if not hasattr(_device, "_agent_mode") or getattr(_device, "_agent_mode") != AgentMode.bin:
                _device.log.warning("Record step only support in bin mode, using screenshot instead.")
                path, link = ScreenAgent.capture_step_picture(file_name, file_desc, _device)
                cur_case.update_step_info(index, screenshot={"link": link.replace("\\", "/"), "name": file_desc})
                return

            path, link = ScreenAgent.get_image_dir_path(_device, file_name, ext=".mp4", exe_type="videoRecord")
            if hasattr(_device, "is_oh"):
                if not hasattr(_device, "recorder_start_time"):
                    return
                frame_count = agent.server.stop_scrcpy()
                if hasattr(_device, "recorder_start_time") and getattr(_device, "recorder_start_time") is not None:
                    setattr(_device, "recorder_start_time", None)
                if int(frame_count) < MIN_FRAME_COUNT:
                    _device.log.debug("video frame is too short, use screenshot instead.")
                    path, link = ScreenAgent.capture_step_picture(file_name, file_desc, _device)
                    cur_case.update_step_info(index, screenshot={"link": link.replace("\\", "/"), "name": file_desc})
                    return
                _device.pull_file("/data/local/tmp/mytest.mp4", path)
            else:
                return
            _device.log.info(
                '<a href="{}" target="_blank">ScreenRecorder: {}'
                '<video style="display: block;" {} controls> <source src="{}"></video>'
                '</a>'.format(link, path, ScreenAgent.resize_image(path, file_type="video"), link))
            cur_case.update_step_info(index, screenshot={"link": link.replace("\\", "/"), "name": file_desc})
        except Exception as e:
            log.error(f"stop screen recorder error, {e}")
            log.debug(traceback.format_exc())

    def terminate(self):
        if self.scrcpy_port is not None and isinstance(self.scrcpy_port, int):
            if hasattr(self._device, "is_oh") or \
                    self._device.usb_type == DeviceConnectorType.hdc:
                log.debug("RecordAgent terminate")
                self._device.connector_command(
                    'fport rm tcp:{} tcp:{}'.format(self.scrcpy_port, self.scrcpy_server_port))
                pid = self._get_scrcpy_uitest_process()
                if pid:
                    self._device.execute_shell_command("kill {}".format(pid))
                RecordAgent.instance.pop(self._device.device_sn)
                self.scrcpy_port = None
