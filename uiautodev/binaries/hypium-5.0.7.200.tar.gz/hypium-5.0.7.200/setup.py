from setuptools import setup

setup(
    name="hypium",
    version="5.0.7.200",
    description="鸿蒙测试框架",
    packages=['hypium',
              'hypium.action',
              'hypium.action.app',
              'hypium.action.host',
              'hypium.action.device',
              'hypium.checker',
              'hypium.advance.deveco_testing',
              'hypium.uidriver.interface',
              'hypium.uidriver.ohos',
              'hypium.uidriver.common',
              'hypium.model',
              'hypium.uidriver',
              'hypium.utils'],
    package_data={
        "hypium": [],
    },
    install_requires=[
        "xdevice",
        "xdevice-ohos",
        "xdevice-devicetest",
    ],
    extras_require={
        "advance": ["opencv-python"],
        "qr": ["pyzbar", "qrcode"]
    },
    include_package_data=True
)
