# !/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2022. All rights reserved.

import sys
import os
from xdevice.__main__ import main_process

if __name__ == "__main__":
    try:
        from hypium.advance.deveco_testing.dvt_step_info import register_task_event_listener
        register_task_event_listener()
    except Exception as e:
        print("TaskEvent listener is not installed")
    main_process()
