class UiDriverPropertyInDevice:
    # hypium的driver配置在device对象里边注册的key
    CONFIG = "_hypium_config"


class ComponentFindMode:
    UITEST = "uitest"  # 优先使用uitest原生控件查找模式
    UITREE = "uitree"  # 优先使用抓取控件树后本地解析模式


class DriverConfig:
    """
    配置driver执行参数, 暂未配置项
    """

    def __init__(self):
        self.component_find_backend = "uitest"

    def update_from_dict(self, config_dict):
        for key in config_dict.keys():
            if key in self.__dict__.keys():
                setattr(self, key, config_dict[key])

    @classmethod
    def from_dict(cls, config_dict):
        config = DriverConfig()
        for key in config_dict.keys():
            if key in config.__dict__.keys():
                setattr(config, key, config_dict[key])
        return config
