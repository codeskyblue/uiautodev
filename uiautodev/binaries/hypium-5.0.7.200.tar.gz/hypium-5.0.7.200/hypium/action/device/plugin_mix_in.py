import weakref
from hypium.utils.cached_property import cached_property


class PluginMixIn:
    """@inner 向driver对象中添加扩展功能模块"""

    @cached_property
    def Assert(self):
        """断言模块"""
        from hypium.checker.assertion import Assert
        return Assert(weakref.proxy(self))

    @cached_property
    def UiTree(self):
        """控件树查找模块"""
        from hypium.uidriver.uitree import UiTree
        return UiTree(weakref.proxy(self))

