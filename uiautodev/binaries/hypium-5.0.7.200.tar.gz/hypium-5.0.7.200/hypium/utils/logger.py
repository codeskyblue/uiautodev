from devicetest.log.logger import platform_logger

hypium_inner_log = platform_logger("HypiumInner")
basic_log = platform_logger("HypiumBasic")
