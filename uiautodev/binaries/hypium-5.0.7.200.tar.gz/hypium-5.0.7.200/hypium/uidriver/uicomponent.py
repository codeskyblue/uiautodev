from .by import By
from .frontend_api import frontend_api, FrontEndClass, get_api_level
from hypium.model.basic_data_type import *
from .interface.uitree import IUiComponent


class UiComponent(FrontEndClass, IUiComponent):
    """
    Ui控件对象, 提供操作控件和获取控件属性接口。
    注意该类的方法只能顺序传参, 不支持通过key=value的方式指定参数
    ```
    from hypium.uidriver.uicomponent import UiComponent
    ```
    """
    def __init__(self, backend_obj_ref):
        super().__init__(backend_obj_ref)
        self.index = None

    def recover(self, device=None) -> bool:
        """启用uicomponent恢复"""
        result = self._recover_component()
        if result is False or result is None or "Component#" not in result:
            self._device.log.error("Fail to recover component: %s" % result)
            return False
        self.activate(result, self._device)
        return True

    def _recover_component(self):
        if self._sourcing_call is None:
            return False
        device = self._device
        api_name = self._sourcing_call[0]
        caller = self._sourcing_call[1]
        args = self._sourcing_call[2]
        for item in args:
            if isinstance(item, FrontEndClass):
                item.deactivate()
        try:
            result = FrontEndClass.call_backend_api(api_name, caller, args, can_defer=False, raw_return=True)
        except Exception as e:
            device.log.error("Rcp failed: %s %s" % (e.__class__.__name__, str(e)))
            return False
        if type(result) == list:
            if self.index is not None and len(result) > self.index:
                comp = result[self.index]
                result.pop(self.index)
                # release unused component
                FrontEndClass._clear_remote_objects(device, result)
                return comp
            else:
                device.log.error("Fail to recover component in list")
                return False
        else:
            return result

    def resolve(self, device):
        if self._resolved:
            return True
        return self.recover()

    @frontend_api(since=8)
    def click(self) -> None:
        """
        @func 点击控件
        """
        pass

    @frontend_api(since=8)
    def doubleClick(self) -> None:
        """
        @func 双击控件
        """
        pass

    @frontend_api(since=8)
    def longClick(self) -> None:
        """
        @func 长按控件
        """
        pass

    @frontend_api(since=8)
    def getId(self) -> int:
        """
        @func 获取控件id
        @return: 在api8之前返回系统为控件分配的数字id，在api9以及之后返回用户为控件设置的id
        """
        pass

    @frontend_api(since=8)
    def getKey(self) -> str:
        """
        @func: 获取用户设置的控件id值，该接口在api9之上被删除，使用getId()替换
        @return: 用户设置的控件id值
        """
        pass

    @frontend_api(since=8)
    def getText(self) -> str:
        """
        @func 获取控件text属性内容
        """
        pass

    @frontend_api(since=8)
    def getType(self) -> str:
        """
        @func 获取控件type属性内容
        """
        pass

    @frontend_api(since=8)
    def isClickable(self) -> bool:
        """
        @func 获取控件clickable属性内容
        """
        pass

    @frontend_api(since=8)
    def isScrollable(self) -> bool:
        """
        @func 获取控件scrollable属性内容
        """
        pass

    @frontend_api(since=8)
    def isEnabled(self) -> bool:
        """
        @func 获取控件enabled属性内容
        """
        pass

    @frontend_api(since=8)
    def isFocused(self) -> bool:
        """
        @func 获取控件focused属性内容
        """
        pass

    @frontend_api(since=9, hmos_since=8)
    def isLongClickable(self):
        """
        @func 获取控件longClickable属性内容
        """
        pass

    @frontend_api(since=9, hmos_since=8)
    def isChecked(self):
        """
        @func 获取控件checked属性内容
        """
        pass

    @frontend_api(since=9, hmos_since=8)
    def isCheckable(self):
        """
        @func 获取控件checkable属性内容
        """
        pass

    @frontend_api(since=10, hmos_since=8)
    def isSelected(self):
        """
        @func 获取控件selected属性内容
        """
        pass

    @frontend_api(since=8)
    def inputText(self, text: str) -> None:
        """
        @func 向控件中输入文本, 注意在HMOS中只能输入英语文本, 输入中文需要使用Hydriver.input_text_by_keyboard
        """
        pass

    @frontend_api(since=9)
    def clearText(self) -> None:
        """
        @func 清除控件中的文本, 注意在HMOS中不生效
        """
        pass

    @frontend_api(since=8)
    def scrollSearch(self, by: By) -> 'UiComponent':
        """
        @func 在当前控件中上下滚动搜索目标控件
        @param by: 目标控件选择器By
        """
        pass

    @frontend_api(since=9, hmos_since=8)
    def scrollToTop(self, speed: int = 600) -> None:
        """
        @func 滚动到当前控件顶部, 注意某些控件可滚动区域和控件实际大小不同可能导致滚动失效
        """
        pass

    @frontend_api(since=9, hmos_since=8)
    def scrollToBottom(self, speed: int = 600) -> None:
        """
        @func 滚动到当前控件底部, 注意某些控件可滚动区域和控件实际大小不同可能导致滚动失效
        """
        pass

    @frontend_api(since=10, hmos_since=8)
    def getDescription(self) -> str:
        """
        @func 获取控件description属性内容
        """
        pass

    @frontend_api(since=9, hmos_since=8)
    def getBounds(self) -> Rect:
        """
        @func 获取控件边框位置
        @return 表示控件边框位置的Rect对象, 可访问该对象的left/right/top/bottom属性获取边框位置
        """
        pass

    @frontend_api(since=9, hmos_since=8)
    def getBoundsCenter(self) -> Point:
        """
        @func 获取控件中心店位置
        @return 表示控件中心点的Point对象, 可访问该对象的x/y属性获取坐标值, 可以调用to_tuple()方法转换为python的(x, y)形式
        """
        pass

    @frontend_api(since=9, hmos_since=8)
    def dragTo(self, target: 'UiComponent') -> None:
        """
        @func 将当前控件拖拽到另一个控件上
        @param target: 另外一个控件对象
        """
        pass

    @frontend_api(since=9)
    def pinchOut(self, scale: float) -> None:
        """
        @func 将控件按指定的比例进行捏合放大
        @param scale: 指定放大的比例, 例如1.5
        """
        pass

    @frontend_api(since=9)
    def pinchIn(self, scale: float) -> None:
        """
        @func 将控件按指定的比例进行捏合缩小
        @param scale: 指定缩小的比例, 例如0.5
        """
        pass

    @frontend_api(since=12)
    def getAllProperties(self) -> JsonBase:
        """
        @func 获取所有属性
        """
        pass


# register type and tools
FrontEndClass.frontend_type_creators['UiComponent'] = lambda ref: UiComponent(ref)
FrontEndClass.frontend_type_creators['Component'] = lambda ref: UiComponent(ref)
# convert return value to specific type according to api name
FrontEndClass.return_handlers['getBoundsCenter'] = lambda json_obj: Point.from_dict(json_obj)
FrontEndClass.return_handlers['getBounds'] = lambda json_obj: Rect.from_dict(json_obj)
FrontEndClass.return_handlers['getDisplaySize'] = lambda json_obj: Point.from_dict(json_obj)
