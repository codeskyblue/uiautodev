# 该文件仅用于保证兼容性
from hypium.utils.logger import *

