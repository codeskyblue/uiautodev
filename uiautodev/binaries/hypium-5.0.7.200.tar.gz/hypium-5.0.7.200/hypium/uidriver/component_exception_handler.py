def handle_component_exception(comp):
    return False
